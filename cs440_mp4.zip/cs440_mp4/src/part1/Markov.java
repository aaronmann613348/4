package part1;

import java.text.DecimalFormat;

public class Markov {
	
	public static char[][] evaluateStuff (Board curBoard, Board tmpBoard, int choice){
		
		//50 iterations
		for(int k = 0 ; k < 50 ; k++){
			//update each square of the board per iteration
			for( int i = 0 ; i < 6 ; i ++){
				for( int j = 0 ; j < 6 ; j++){
					Square s = curBoard.board[i][j];
					if(choice == 1){
						if(s.wall || s.terminal)
							continue;
							tmpBoard.board[i][j].util = curBoard.findUtil(s,choice);
					}
					if(choice == 2){
						if(s.wall)
							continue;
							tmpBoard.board[i][j].util = curBoard.findUtil2(s,choice, k);
						

					}
				}
			}
			printUtils(curBoard);
			System.out.println();
			curBoard.board = tmpBoard.board;
			tmpBoard = new Board();
		}
		
		printUtils(curBoard);
		return null;
	
	}
	
	public static void printUtils(Board board){
		DecimalFormat df = new DecimalFormat("#.######");
		System.out.println("Heyyyyyyyy");

		for( int i = 0 ; i < 6 ; i ++){
			for( int j = 0 ; j < 6 ; j++){
				String d = df.format(board.board[i][j].util);
				if(d.length() < 9){
					int count = 9 - d.length();
					while (count > 0 ){
						
						System.out.print(" ");
						count--;
					}
				}
				
				System.out.println(df.format(board.board[i][j].util)+"  ");
			}
			//System.out.println();

		}
	}
	

}
