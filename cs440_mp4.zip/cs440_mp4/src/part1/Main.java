package part1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("which part would you like to choose?  1) Part one terminal state. 2) Part one non terminal state. 3) Part two");
		int choice = sc.nextInt();
		
		if(choice == 1 || choice == 2){
			Board curBoard = new Board();
			Board tmpBoard = new Board();
			char[][] policy = Markov.evaluateStuff(curBoard, tmpBoard, choice);
			return;
		}
		
		else if(choice == 3){
			
			Qboard curBoard = new Qboard();
			
			TDQLearning.evaluateStuffTwo(curBoard);
			return;
		}
	}
}
