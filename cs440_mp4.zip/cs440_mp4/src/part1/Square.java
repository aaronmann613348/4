package part1;

public class Square {
	int x;
	int y;
	double util;
	double reward;
	boolean terminal;
	int direction;
	boolean wall;
	boolean start;
	
	public Square(int x, int y){
		this.x = x;
		this.y = y;
		reward = -.04;
		terminal = false;
		util = 0;
		wall = false;
		start = false;
	}
}
