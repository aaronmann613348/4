package part1;

import java.text.DecimalFormat;

public class TDQLearning {

	final static int UP = 0;
	final static int DOWN = 1;
	final static int LEFT = 2;
	final static int RIGHT = 3;
	
	public static double[][] evaluateStuffTwo(Qboard curboard){
		
		//String actionSequence = "Action        a  ";
		//String trace ="Current state s ";
		int curX = 3;
		int curY = 1;
		int numTrial = 0;
		int timeStep = 1;
		
		int adsf = 10;
		//while(adsf > 0){
		while(numTrial < 30000){
			
			QSquare s = curboard.qboard[curX][curY];
			//trace+="(" + s.x + "," + s.y + ") ";
			
			int nextAction = curboard.getNextAction(s);
			//actionSequence+=nextAction+"     ";
			
			QSquare nextState = curboard.updateQValue(s, nextAction, timeStep);
			
			if(nextState.terminal){
				numTrial++;
				timeStep++;
				curX = 3;
				curY = 1;
				continue;
			}
			
			curX = nextState.x;
			curY = nextState.y;
			timeStep++;
		}
		 adsf = adsf - 1;
		//}
		
		printUtils(curboard);
		
		//System.out.println(actionSequence);
		//System.out.println(trace);
		
		return null;
	}
	
	public static void printUtils(Qboard board){
		DecimalFormat df = new DecimalFormat("#.######");
		for( int i = 0 ; i < 6 ; i ++){
			for( int j = 0 ; j < 6 ; j++){
				
				
				String result = new String();
				double maxQ = -99;
				
				if(board.qboard[i][j].terminal){
					maxQ = board.qboard[i][j].reward;					
				}
				else {
					for(int x=0; x<4; x++){
						if(board.qboard[i][j].actionToQ.get(x) > maxQ)
						{
							maxQ = board.qboard[i][j].actionToQ.get(x);
						}
					}
				}

				String d = df.format(maxQ);
				if(d.length() < 9){
					int count = 9 - d.length();
					while (count > 0 ){
						
						System.out.print(" ");
						count--;
					}
				}
				
				System.out.print(df.format(maxQ)+"  ");
				
				
				
			}
			System.out.println();
		}
	}
}
