package part1;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Qboard {
	
	final static int UP = 0;
	final static int DOWN = 1;
	final static int LEFT = 2;
	final static int RIGHT = 3;
	final static double RPLUS = 5;
	final static double GAMMA = 0.99;
	QSquare [][] qboard;
	
	public Qboard() {
		this.qboard = new QSquare [6][6];
		
		for(int i = 0; i < 6; i++){
			for(int j = 0; j < 6; j++){
					qboard[i][j] = new QSquare (i,j);
					qboard[i][j].reward = -.04;
			}
		}
		
		qboard[0][1].terminal = true;
		qboard[0][1].actionToQ.put(0, -1.0);
		qboard[0][1].reward = -1;
		
		qboard[1][3].wall = true;
		qboard[2][3].wall = true;
		qboard[3][3].wall = true;
		qboard[5][3].wall = true;
		
		qboard[1][4].terminal = true;
		qboard[1][4].actionToQ.put(0, -1.0);
		qboard[1][4].reward = -1;
		
		
		qboard[2][5].terminal = true;
		qboard[2][5].actionToQ.put(0, 3.0);
		qboard[2][5].reward = 3;
		
		qboard[5][0].terminal = true;
		qboard[5][0].actionToQ.put(0, 1.0);
		qboard[5][0].reward = 1;
		
		qboard[5][1].terminal = true;
		qboard[5][1].actionToQ.put(0, -1.0);
		qboard[5][1].reward = -1;
		
		qboard[5][4].terminal = true;
		qboard[5][4].actionToQ.put(0, -1.0);
		qboard[5][4].reward = -1;
		
		qboard[5][5].terminal = true;
		qboard[5][5].actionToQ.put(0, -1.0);
		qboard[5][5].reward = -1;
		
		qboard[3][1].start = true;

	}

	
	
	
	public QSquare getNextState(QSquare s, int action){
		double random = Math.random();
		QSquare ns;
		
		//80% going in direction
		if(random < 0.8){
			switch(action){
			case UP:
				if(isInBounds(s.x-1,s.y))
					ns = qboard[s.x-1][s.y];
				else 
					ns = s;
				break;
			case DOWN:
				if(isInBounds(s.x+1,s.y))
					ns = qboard[s.x+1][s.y];
				else 
					ns = s;
				break;
			case LEFT:
				if(isInBounds(s.x,s.y-1))
					ns = qboard[s.x][s.y-1];
				else 
					ns = s;
				break;
			default:
				if(isInBounds(s.x,s.y+1))
					ns = qboard[s.x][s.y+1];
				else 
					ns = s;
				break;
			}
		//10% left
		} else if (random < 0.9){
			switch(action){
			case UP:
				if(isInBounds(s.x,s.y-1))
					ns = qboard[s.x][s.y-1];
				else 
					ns = s;
				break;
			case DOWN:
				if(isInBounds(s.x,s.y+1))
					ns = qboard[s.x][s.y+1];
				else 
					ns = s;
				break;
			case LEFT:
				if(isInBounds(s.x+1,s.y))
					ns = qboard[s.x+1][s.y];
				else 
					ns = s;
				break;
			default:
				if(isInBounds(s.x-1,s.y))
					ns = qboard[s.x-1][s.y];
				else 
					ns = s;
				break;
			}
		//10% right
		} else {
			switch(action){
			case UP:
				if(isInBounds(s.x,s.y+1))
					ns = qboard[s.x][s.y+1];
				else 
					ns = s;
				break;
			case DOWN:
				if(isInBounds(s.x,s.y-1))
					ns = qboard[s.x][s.y-1];
				else 
					ns = s;
				break;
			case LEFT:
				if(isInBounds(s.x-1,s.y))
					ns = qboard[s.x-1][s.y];
				else 
					ns = s;
				break;
			default:
				if(isInBounds(s.x+1,s.y))
					ns = qboard[s.x+1][s.y];
				else 
					ns = s;
				break;
			}
			
		}
		return ns;
		
	}
	
	public QSquare updateQValue(QSquare s, int action, int t){
		QSquare ns = getNextState(s,action);
		
		double Q = s.actionToQ.get(action);
		double delta = 0;
		if(!ns.terminal)
			delta = 600000.0*(s.reward+GAMMA*getMaxUtility(ns)-Q)/(double)(599999+t);
		else 
			delta = 600000.0*(s.reward+GAMMA*ns.reward-Q)/(double)(599999+t);
		Q = Q + delta;
		
		this.qboard[s.x][s.y].actionToQ.put(action, Q);
		
		return ns;
	}

	
	public double getMaxUtility(QSquare qs){
		Set<Entry<Integer, Double>> list = qs.actionToQ.entrySet();
		Iterator<Entry<Integer, Double>> it = list.iterator();
		double maxQValue = -99;
		while(it.hasNext()){
			Entry<Integer, Double> pair = it.next();
			
			if(pair.getValue() > maxQValue){
				maxQValue = pair.getValue();
			}
		}
		
		return maxQValue;
	}
	
	
	
	public int getNextAction(QSquare qs){
		//When n < 2, pick the action that has taken least
		
		//Get the action with largest Q value
		Set<Entry<Integer, Double>> list = qs.actionToQ.entrySet();
		Iterator<Entry<Integer, Double>> it = list.iterator();
		double maxQValue = -99;
		int maxAction = -1;
		
		while(it.hasNext()){
			Entry<Integer, Double> pair = it.next();
			int action = pair.getKey();
			
			int n = qs.actionCount.get(action);
			
			if(n < 100){
				maxQValue = RPLUS;
				maxAction = action;
			} else if(pair.getValue() > maxQValue){
				maxQValue = pair.getValue();
				maxAction = pair.getKey();
			}
		}
		
		qs.actionCount.put(maxAction, qs.actionCount.get(maxAction)+1);
		return maxAction;
	}
	
	public double findUtilTwo(){
		double asdf = 0;
		return asdf;
	}
	
	private double findUtilTwoHelper(){
		double stupid = 0;
		return stupid;
	}

	private boolean isInBounds(int x, int y){
		return x >= 0 && y >= 0 && x < 6 && y < 6 && !this.qboard[x][y].wall;
	}

	boolean isTerminal(int x, int y){
		return this.qboard[x][y].terminal;
	}
}


	