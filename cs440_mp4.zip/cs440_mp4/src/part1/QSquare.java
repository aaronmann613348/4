package part1;

import java.util.HashMap;

public class QSquare {
	int x;
	int y;
	final static int UP = 0;
	final static int DOWN = 1;
	final static int LEFT = 2;
	final static int RIGHT = 3;
	

	double reward;
	boolean terminal;
	int direction;
	boolean wall;
	boolean start;

	
	public HashMap<Integer, Double> actionToQ;
	public HashMap<Integer, Integer> actionCount;
	
	
	public QSquare(int x, int y){
		this.x = x;
		this.y = y;
		reward = -.04;
		terminal = false;

		wall = false;
		start = false;
		
		actionToQ = new HashMap<Integer, Double>();
		actionToQ.put(UP, 0.0);
		actionToQ.put(DOWN, 0.0);
		actionToQ.put(LEFT, 0.0);
		actionToQ.put(RIGHT, 0.0);
		
		
		actionCount = new HashMap<Integer, Integer>();
		actionCount.put(UP, 0);
		actionCount.put(DOWN, 0);
		actionCount.put(LEFT, 0);
		actionCount.put(RIGHT, 0);
	
	}
}
