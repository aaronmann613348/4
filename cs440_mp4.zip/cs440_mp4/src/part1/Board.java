package part1;

public class Board {
	
	final static int UP = 0;
	final static int DOWN = 1;
	final static int LEFT = 2;
	final static int RIGHT = 3;
	final static double GAMMA = 0.99;
	Square [][] board;
	
	public Board() {
		this.board = new Square [6][6];
		
		for(int i = 0; i < 6; i++){
			for(int j = 0; j < 6; j++){
					board[i][j] = new Square (i,j);
					board[i][j].reward = -.04;
					board[i][j].util = 0.0;
			}
		}
		
		board[0][1].terminal = true;
		board[0][1].reward = -1;
		board[0][1].util = -1;
		
		board[1][3].wall = true;
		board[2][3].wall = true;
		board[3][3].wall = true;
		board[5][3].wall = true;
		
		board[1][4].terminal = true;
		board[1][4].reward = -1;
		board[1][4].util = -1;
		
		
		
		board[2][5].terminal = true;
		board[2][5].reward = 3;
		board[2][5].util = 3;
		
		board[5][0].terminal = true;
		board[5][0].reward = 1;
		board[5][0].util = 1;
		
		board[5][1].terminal = true;
		board[5][1].reward = -1;
		board[5][1].util = -1;
		
		board[5][4].terminal = true;
		board[5][4].reward = -1;
		board[5][4].util = -1;
		
		board[5][5].terminal = true;
		board[5][5].reward = -1;
		board[5][5].util = -1;
		
		board[3][1].start = true;

	}
	
	
	public double findUtil(Square s, int choice){
		double max = -99.0;
		double tmp = 0.0;
		for(int i = 0 ; i < 4 ; i++){
			tmp = findUtilHelper(i, s);

			if (tmp > max){
				max = tmp;
			}
		}
		return max;
	}
	
	
	private double findUtilHelper(int direction, Square s){
		double max = -0.04;
		if(s.terminal == true)
			max = s.reward;
		
		double left = 0.0;
		double right = 0.0;
		double straight = 0.0;
		double u = 0.0;
		switch (direction){
		case UP:
			if(isInBounds(s.x-1, s.y)){
				straight = 0.8*GAMMA*this.board[s.x-1][s.y].util;
				
				max += straight;
			} 
			else {
				u = 0.8*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y-1)){
				left = 0.1*GAMMA*this.board[s.x][s.y-1].util;
				
				max += left;
			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y+1)){
				right = 0.1*GAMMA*this.board[s.x][s.y+1].util;
				
				max += right;
			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		case DOWN:
			if(isInBounds(s.x+1, s.y)){
				straight = 0.8*GAMMA*this.board[s.x+1][s.y].util;
				
				max += straight;
			}
			else {
				u = 0.8*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y+1)){
				left = 0.1*GAMMA*this.board[s.x][s.y+1].util;
				
				max += left;

			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y-1)){
				right = 0.1*GAMMA*this.board[s.x][s.y-1].util;
				
				max += right;
			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		case LEFT:
			if(isInBounds(s.x, s.y-1)){
				straight = 0.8*GAMMA*this.board[s.x][s.y-1].util;
				
				max += straight;
			}
			else {
				u = 0.8*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x+1, s.y)){
				left = 0.1*GAMMA*this.board[s.x+1][s.y].util;
				
				max += left;
			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x-1, s.y)){
				right = 0.1*GAMMA*this.board[s.x-1][s.y].util;
				
				max += right;
			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		case RIGHT:
			if(isInBounds(s.x, s.y+1)){
				straight = 0.8*GAMMA*this.board[s.x][s.y+1].util;
				
				max += straight;
			}
			else {
				u = 0.8*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x-1, s.y)){
				left = 0.1*GAMMA*this.board[s.x-1][s.y].util;
				
				max += left;
			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x+1, s.y)){
				right = 0.1*GAMMA*this.board[s.x+1][s.y].util;
				
				max += right;
			}
			else {
				u = 0.1*GAMMA*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		}
		return max;
	}
	
	
	public double findUtil2(Square s, int choice, int move){
		double max = -99.0;
		double tmp = 0.0;
		for(int i = 0 ; i < 4 ; i++){
			tmp = findUtilHelper2(i, s, move);

			if (tmp > max){
				max = tmp;
			}
		}
		return max;
	}
	
	
	private double findUtilHelper2(int direction, Square s, int move){
		double max = -0.04;
		if(s.terminal == true)
			max = s.reward;
		
		double left = 0.0;
		double right = 0.0;
		double straight = 0.0;
		double u = 0.0;
		switch (direction){
		case UP:
			if(isInBounds(s.x-1, s.y)){
				straight = 0.8*(Math.pow(GAMMA, move))*this.board[s.x-1][s.y].util;
				
				max += straight;
			} 
			else {
				u = 0.8*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y-1)){
				left = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y-1].util;
				
				max += left;
			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y+1)){
				right = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y+1].util;
				
				max += right;
			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		case DOWN:
			if(isInBounds(s.x+1, s.y)){
				straight = 0.8*(Math.pow(GAMMA, move))*this.board[s.x+1][s.y].util;
				
				max += straight;
			}
			else {
				u = 0.8*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y+1)){
				left = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y+1].util;
				
				max += left;

			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x, s.y-1)){
				right = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y-1].util;
				
				max += right;
			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		case LEFT:
			if(isInBounds(s.x, s.y-1)){
				straight = 0.8*(Math.pow(GAMMA, move))*this.board[s.x][s.y-1].util;
				
				max += straight;
			}
			else {
				u = 0.8*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x+1, s.y)){
				left = 0.1*(Math.pow(GAMMA, move))*this.board[s.x+1][s.y].util;
				
				max += left;
			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x-1, s.y)){
				right = 0.1*(Math.pow(GAMMA, move))*this.board[s.x-1][s.y].util;
				
				max += right;
			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		case RIGHT:
			if(isInBounds(s.x, s.y+1)){
				straight = 0.8*(Math.pow(GAMMA, move))*this.board[s.x][s.y+1].util;
				
				max += straight;
			}
			else {
				u = 0.8*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x-1, s.y)){
				left = 0.1*(Math.pow(GAMMA, move))*this.board[s.x-1][s.y].util;
				
				max += left;
			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			if(isInBounds(s.x+1, s.y)){
				right = 0.1*(Math.pow(GAMMA, move))*this.board[s.x+1][s.y].util;
				
				max += right;
			}
			else {
				u = 0.1*(Math.pow(GAMMA, move))*this.board[s.x][s.y].util;
				max += u;
			}
			break;
		}
		return max;
	}
		
	
	
	
	public double findUtilTwo(){
		double asdf = 0;
		return asdf;
	}
	
	private double findUtilTwoHelper(){
		double stupid = 0;
		return stupid;
	}

	private boolean isInBounds(int x, int y){
		return x >= 0 && y >= 0 && x < 6 && y < 6 && !this.board[x][y].wall;
	}

}


	