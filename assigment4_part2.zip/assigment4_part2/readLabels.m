function labels = readLabels(labelFile)
    fid = fopen(labelFile, 'r');
    labels = fscanf(fid, '%i', [1, 5000])';
    fclose(fid);
end