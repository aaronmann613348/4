function [accuracy, confusionMatrix] = computeAccuracy(w)
    
    x = readTestFeatures('testFeatures.txt', 784);
    y = readTestLabels('testLabels.txt');

    %x(:,end) = 1.0;

    k = size(x,1);
    numCorrect = 0.0;
    results = zeros(10,1);

    confusionMatrix = zeros(10,10);
    
      NewCol = ones(1000,1);
    %Add new column
    x = [x, NewCol];
    x(:,785) = 1.0;
    
    for i=1:k

        x_i = x(i,:)';
        y_i = y(i);

        %find all the x*w values for each class
        for j = 1:10
            results(j) = dot(x_i,w(j,:));
        end

        maxDot = -99999.0;
        maxIndex = 1;
        for j = 1:10
            if (results(j)> maxDot)
                maxDot = results(j);
                maxIndex = j;
            end
        end

        yPredicted = maxIndex - 1;
        if y_i==yPredicted
            numCorrect = numCorrect + 1.0;
        end
        
        
        confusionMatrix(y_i+1, yPredicted+1) = confusionMatrix(y_i+1, yPredicted+1) + 1.0;
        
        
    end
    
    confusionMatrix(1,:) = 100.0*confusionMatrix(1,:)/90.0;
    confusionMatrix(2,:) = 100.0*confusionMatrix(2,:)/108.0;
    confusionMatrix(3,:) = 100.0*confusionMatrix(3,:)/103.0;
    confusionMatrix(4,:) = 100.0*confusionMatrix(4,:)/100.0;
    confusionMatrix(5,:) = 100.0*confusionMatrix(5,:)/107.0;
    confusionMatrix(6,:) = 100.0*confusionMatrix(6,:)/92.0;
    confusionMatrix(7,:) = 100.0*confusionMatrix(7,:)/91.0;
    confusionMatrix(8,:) = 100.0*confusionMatrix(8,:)/106.0;
    confusionMatrix(9,:) = 100.0*confusionMatrix(9,:)/103.0;
    confusionMatrix(10,:) = 100.0*confusionMatrix(10,:)/100.0;
    accuracy = numCorrect/k;
    disp('accuracy: ')
    accuracy
end