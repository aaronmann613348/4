
% Function for reading in the files into
function data = readTestFeatures(featureFile, nFeatures)
    fid = fopen(featureFile, 'r');
    data = fscanf(fid, '%i', [nFeatures, inf])';
    fclose(fid);
end