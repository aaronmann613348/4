

function [w, errors, x, y, k, n, percentCorrect] = learn_perceptron()
    % read training data into matrix x
    %x = readFeatures('trainingFeatures.txt', 784);
    x = csvread('trainingFeatures.dat');
    %size(x)
    
    % read training labels in vector y
    y = readLabels('trainingLabels.txt');

    % k instances (5000) and n features (785)
    [k,n] = size(x);
    %set an extra feature column to 1 for each instance in training set for bias
    NewCol = ones(5000,1);
    %Add new column
    x = [x, NewCol];
    x(:,785) = 1.0;
   
    % set the last element in weight vectors to be theta (bias); this
    % value we can play around with
    w = zeros(10,n+1);
    
    rng(0,'twister');
    a = -1;
    b = 1;
  %  w = (b-a).*rand(10,n+1) + a;
    
    w(:,end) = 0.0;

    num_errors = 0.0;
    %keep track of number of errors per instance
    errors = zeros(1,150);

    num_iters = 0;

    % vector to store the 1 dot products w*x for each class's weight vector
    dotResults = zeros(10,1);


    while(num_iters ~= 150)
        
        % for shuffling instance orders
        r = randperm(size(x,1));
        % x =  x(r,:);
        % y = y(r);
        
        % set learning rate in terms of which iteration it is
        eta = 1000.0 / (1000.0 + num_iters);
        
        % number of errors in a given iteration
        local_errors = 0.0;
        
        % iterate over all 5000 training images
        for i = 1:k
            
            % for shuffling instances
            ii = i;
            
            % Get current example label and feature vector
            y_i = y(ii);
            x_i = x(ii,:)';
            
            %find all the x*w values for each class
            for j = 1:10
                dotResults(j) = dot(x_i,w(j,:));
            end

            maxDot = -9999.0;
            labelGuessIndex = 1;
            for m = 1:10
                if (dotResults(m)> maxDot)
                    maxDot = dotResults(m);
                    labelGuessIndex = m;
                end
            end
       
            labelGuess = labelGuessIndex - 1;
            
            % example i from class c gets misclassified as c'
            if labelGuess ~= y_i
            	w(labelGuessIndex,:) = w(labelGuessIndex,:) - eta*(x_i)';
                w(y_i+1,:) = w(y_i+1,:) + eta*(x_i)';          
                num_errors = num_errors+1;
                local_errors = local_errors +1;
            end
            % Store current error count
            %errors(i) = num_errors;
            

            
        end
        
%         % printing stuff for debugging
%         if num_iters == 501
%             dotResults
%             labelGuess
%         	y_i
%         end
        
        if local_errors == 0
            %num_iters
            break
        end
        
        if num_iters == 150
            
        	%local_errors
        end
        errors(num_iters+1) = 100.0 - (100.0*local_errors) / 5000.0;
        num_iters = num_iters + 1;
    end
    percentCorrect = (1.0*local_errors) / 5000.0;
end


