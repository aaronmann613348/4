[w, errors, x, y, k, n, acc] = learn_perceptron();

[accuracy, cofusionMatrix] = computeAccuracy(w);
k
n
acc

names{1, 1} = 'hi';
plot_figure(1, 'Perceptron Learning Rate', 'Number of Epochs', '% Correctly Classified', names, errors);