
% Function for reading in the files into
function data = readFeatures(featureFile, nFeatures)
    fid = fopen(featureFile, 'r');
    data = fscanf(fid, '%d', [784 inf])';
    fclose(fid);
end


