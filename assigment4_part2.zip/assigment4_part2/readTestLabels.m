function labels = readTestLabels(labelFile)
    fid = fopen(labelFile, 'r');
    labels = fscanf(fid, '%i', [1, inf])';
    fclose(fid);
end